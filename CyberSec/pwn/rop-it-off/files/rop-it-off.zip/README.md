# ROP It Off

**`Author:`** chenx3n

## Description

> Yeah yeah we know you're a programmer and all, but have you ever heard of return oriented programming?  
> You might need to look that up to get through this challenge.  

**Connect with**: `nc -v devfest22-cybersec.gdgalgiers.com 1401`

### Attachments

[rop-it-off.zip](./rop-it-off.zip)
