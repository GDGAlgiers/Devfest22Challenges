# My First Overflow

**`Author:`** chenx3n

## Description

> I made this small program that reads your input, but the buffer is kind of small, I hope that won't be a problem!  

**Connect with**: `nc -v devfest22-cybersec.gdgalgiers.com 1400`  

### Attachments

[my-first-overflow.zip](./my-first-overflow.zip)
