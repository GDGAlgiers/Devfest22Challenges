# You, Me & Printf

**`Author:`** chenx3n

## Description

> There is no escape, it's just you, me and this printf.  

**Note**: The binary is already patched to use the provided libc and linker.  

**Connect with**: `nc -v devfest22-cybersec.gdgalgiers.com 1402`

[you-me-printf.zip](./you-me-printf.zip)
