# Gu1Ld5

**`Authors:`** rx0f, yh_0x7

## Description

> Have you ever heard about guilds?  

**Connect with**: http://devfest22-cybersec.gdgalgiers.com:1300
