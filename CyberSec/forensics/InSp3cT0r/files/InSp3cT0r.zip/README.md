# InSp3cT0r

**`Author:`** yh_0x7

## Description

> Can U become the next inspector gadget???

### Attachments

[InSp3cT0r.zip](./InSp3cT0r.zip)
