# OPTIONS

**`Author:`** rx0f

## Description

> I opened an online restaurant, do you think you have all the options?  

**Connect with**: http://devfest22-cybersec.gdgalgiers.com:1600
