# World Cup

**`Author:`** chenx3n

## Description

> World Cup 2022 has already started so I made this small app to show support for participating teams!  
> Nothing could go wrong, right?  

**Connect with** : http://devfest22-cybersec.gdgalgiers.com:1601

### Attachments

[world-cup.zip](./world-cup.zip)
