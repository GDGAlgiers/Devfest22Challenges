# BiScU1tS

**`Author:`** yh_0x7

## Description

> I baked something very special for you. Can you find it?  

**Connect with**: http://devfest22-cybersec.gdgalgiers.com:1602
