# rutomate

**`Author:`** ouxs

## Description

> Let's do another classic reverse flag checker challenge.  

### Attachments

[rutomate.zip](./rutomate.zip)
