# My first diamond

**`Author:`** [rx0f](https://github.com/rx0f)

## Description

> I used diamonds to verify the input, can you find the correct result?  

### Attachments

[my-first-diamond.zip](./my-first-diamond.zip)
