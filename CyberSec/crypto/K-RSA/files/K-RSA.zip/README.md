# K-RSA

**`Author:`** ouxs

## Description

> I wanted to play with RSA a bit and came out with this cool idea. I called it K-RSA

### Attachments

[K-RSA.zip](./K-RSA.zip)
