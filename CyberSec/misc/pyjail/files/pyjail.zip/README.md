# pyjail

**`Author:`** ouxs

## Description

> I've been testing jails for a while now and none of them managed to keep me.  

**Connect with**: `nc -v devfest22-cybersec.gdgalgiers.com 1200`

### Attachments

[pyjail.zip](./pyjail.zip)
